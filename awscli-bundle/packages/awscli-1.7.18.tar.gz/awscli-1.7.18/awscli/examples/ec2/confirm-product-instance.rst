**To confirm the product instance**

This example determines whether the specified product code is associated with the specified instance.

Command::

  aws ec2 confirm-product-instance --product-code 774F4FF8 --instance-id i-5203422c

Output::

  {
    "OwnerId": "123456789012"
  }