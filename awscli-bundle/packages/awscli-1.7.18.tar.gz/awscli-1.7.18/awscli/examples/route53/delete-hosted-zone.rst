**To delete a hosted zone**

The following ``delete-hosted-zone`` command deletes the hosted zone with an ``id`` of  ``Z36KTIQEXAMPLE``::

  aws route53 delete-hosted-zone --id Z36KTIQEXAMPLE

